# or_gate
